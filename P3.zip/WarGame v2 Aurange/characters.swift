//
//  characters.swift
//  WarGame v2 Aurange
//
//  Created by Thomas Aurange on 26/10/2019.
//  Copyright © 2019 Thomas Aurange. All rights reserved.
//

import Foundation

//MARK: - Init of Character Class
class Character {
    
    var membership: Team?
    var characterName: String = ""
    var role: Role?
    var isCharacterStillAlive: Bool = true
    
    
    init(membership: Team) {
        self.membership = membership
        
        setCharacterName()
        setCharacterRole()
    }

    
    //Function to choose the name of each character choosen by the players
    func setCharacterName() {
        // check for duplicate names
        var isnameDuplicated: Bool = false
        repeat {
            print("      Quel est son nom ? ", terminator: "")
            
            if let inputData = readLine() {
                
                if !inputData.isEmpty {
                    // check for duplicate team names
                    isnameDuplicated = Game.checkIfDuplicatedName(name: inputData)
                    if isnameDuplicated {
                        print("\n   \(const.NAME_ALREADY_CHOOSEN)")
                    } else {
                        self.characterName = inputData
                        Game.usedNames.append(inputData.uppercased())
                    }
                } else {
                    print("\n   Saisie invalide!\n")
                    isnameDuplicated = true
                    
                } // end of : if !inputData.isEmpty {
            } //end of : if let teamName = readLine()
        } while isnameDuplicated == true
} //end of : func setTeamName()


    
    //MARK: - Function to choose and display the character features
    
    
    //Function to set up weapon, damage and life for each role
    func setCharacterRole() {
        //variable of input verification
        var isInputOk: Bool = false
        
        //Displaying of the characteristics of each characters
        print(" Qu'elle est sont role ?")
        
        print("\nTANK\n")
        print("1: \(const.juggenautRole)      Vie : \(const.juggenautLife)      Dégats : \(const.juggenautDamage)")
        
        print("2: \(const.captainRole)       Vie : \(const.captainLife)      Dégats : \(const.captainDamage)")
        
        print("3: \(const.paladinRole)         Vie : \(const.paladinLife)      Dégats : \(const.paladinDamage)")
        
        print("\nATTAQUANT\n")
        print("4: \(const.ninjaRole)           Vie : \(const.ninjaLife)      Dégats : \(const.ninjaDamage)")
        
        print("5: \(const.hunterRole)        Vie : \(const.hunterLife)      Dégats : \(const.hunterDamage)")
        
        print("6: \(const.sheriffRole)         Vie : \(const.sheriffLife)      Dégats : \(const.sheriffDamage)")
        
        print("\nSOIGNEUR\n")
        print("7: \(const.druidRole)          Vie : \(const.druidLife)      Soins : \(const.druidDamage)")
        
        print("8: \(const.chamanRole)          Vie : \(const.chamanLife)      Soins : \(const.chamanDamage)")
         
        print("9: \(const.priestRole)          Vie : \(const.priestLife)      Soins : \(const.priestDamage)")

        //Display of character to choose
        repeat {
            print("      ", terminator: "")
            if let input = readLine() {
                if input == "1" || input == "2" || input == "3" || input == "4" || input == "5" || input == "6" || input == "7" || input == "8" || input == "9" {
                    if isNotDuplicatedRoles(choice: Int(input)!) {
                        membership?.memRoles.append(Int(input)!)
                        switch input {
                        case "1" :
                            isInputOk = true
                            self.role = JuggernautRole(heritageOf: self)
                        case "2" :
                            isInputOk = true
                            self.role = CaptainRole(heritageOf: self)
                        case "3" :
                            isInputOk = true
                            self.role = PaladinRole(heritageOf: self)
                        case "4" :
                            isInputOk = true
                            self.role = NinjaRole(heritageOf: self)
                        case "5" :
                            isInputOk = true
                            self.role = HunterRole(heritageOf: self)
                        case "6" :
                            isInputOk = true
                            self.role = SheriffRole(heritageOf: self)
                        case "7" :
                            isInputOk = true
                            self.role = DruidRole(heritageOf: self)
                        case "8" :
                            isInputOk = true
                            self.role = ChamanRole(heritageOf: self)
                        case "9" :
                            isInputOk = true
                            self.role = PriestRole(heritageOf: self)
                        default :
                            break
                        }//End of switch input
                    } else {
                        isInputOk = false
                        print(const.TEAM_ROLE_ALREADY_CHOOSEN)
                    } // end of :  if !checkDuplicatedRoles(role: Int(inputKeybord)!)
                } else { // if (result != nil) {
                    isInputOk = false
                    print("      Erreur de saisie, recommencez !\n")
                }// end of : if (result != nil) {
            } // end of : if let inputKeybord = readLine() {
        } while isInputOk == false
    } // end of : func setPlayerRole()
    
    
    //Function to print choosen character characteristics
    func showInfoAboutCharacter() {
        if let characterRole = role {
            if characterRole.roleName == const.druidRole || characterRole.roleName == const.chamanRole || characterRole.roleName == const.priestRole {
            print("\nVous avez choisit \(characterRole.roleName) PV : \(characterRole.roleLife) SOINS : \(characterRole.roleWeapon.weaponDamage)")
            } else {
                print("\nVous avez choisit \(characterRole.roleName) PV : \(characterRole.roleLife) DGT : \(characterRole.roleWeapon.weaponDamage)")
            }
        }//End of if let characterRole
    }//End of func showInfoAboutCharacter()


    
    //Function to check if duplicate name
    func isNotDuplicatedRoles(choice: Int) -> Bool {
        var notDuplicatedRoles: Bool = true
        if (membership?.memRoles.contains(choice))! {
            notDuplicatedRoles = false
        }
        return notDuplicatedRoles
    } // end of : func checkDuplicateName()
    
    
    
    
//MARK: - Dodge and Fight func
    
    
    //Function for real fight
    func fight (attackingTeam: Team, attackedTeam: Team) {
        //unwrap role
        guard let role = self.role else {fatalError()}
        guard let currentStriker = attackingTeam.concernedCharacter!.role else {fatalError()}
        
        // unique instruction concretizing the virtual fight
        role.roleLife = role.roleLife - currentStriker.roleWeapon.weaponDamage
      
        // in case of negative roleLife
        if role.roleLife <= 0 {
            role.roleLife = 0
            
          
        }
    } // end of : func fight
    
    //function for real dodge
    func dodge (attackingTeam: Team, attackedTeam: Team) {
        //unwrap role
        guard let role = self.role else {fatalError()}
        guard let currentStriker = attackingTeam.concernedCharacter?.role else {fatalError()}
        // // unique instruction concretizing the virtual dodge
        currentStriker.roleLife = currentStriker.roleLife - role.roleWeapon.weaponDamage
        // in case of negative roleLife
        if currentStriker.roleLife <= 0 {
            currentStriker.roleLife = 0
        }
    } // end of : func dodge
    

} // end of : class Character





// MARK: - Game extension for healing functions
extension Character {
    
    //Function for healing
    func healing(attackingTeam: Team, attackedTeam: Team) -> Bool {

        guard let role = self.role else {fatalError()}
        
        print ("\n      C'est \(self.characterName) (\(role.roleName)) qui a été choisi !!!\n")
        
        // count of characters dead and/or with maxLife
        let (allTheFriendsOfTheTeamHaveDied, someFriendsOfTheTeamHaveADecreasedLife, _, allTheFriendsOfTheTeamAreDeadOrhaveMaxLife) = workforceInventory(team: attackingTeam)
        
//        if false {
//        displayOfBooleanInHealing(allTheFriendsOfTheTeamHaveDied, allTheFriendsOfTheTeamHaveAMaxLife, allTheFriendsOfTheTeamAreDeadOrhaveMaxLife, someFriendsOfTheTeamHaveADecreasedLife)
//        }
        // in case of nobody to heal - new choice available
        var newChoice: Bool = false

        // test if the magus is the last survivor (and of course his team will lose)
        if allTheFriendsOfTheTeamHaveDied {
            theMagusWhoRemainedAloneFlees(team: attackingTeam, attackingTeam: attackingTeam, attackedTeam: attackedTeam)
        }

        // if all the character dead or in full life
        if allTheFriendsOfTheTeamAreDeadOrhaveMaxLife && !allTheFriendsOfTheTeamHaveDied {
        
            print("         Tous les membres de l'équipe sont soit morts soit en pleine santé !\n\n         Le choix du \(role.roleName) est impossible !\n\n         Equipe \(attackingTeam.teamName) choisissez un autre Champion pour attqué !")
            
            // nobody to heal so new choice available
            newChoice = true
      
        }

        if someFriendsOfTheTeamHaveADecreasedLife {
                        
            // display them
            showPlayersToTreat(attackingTeam: attackingTeam)
            
            //choice of the player to treat
            let characterChoosen = choiceOfAPlayerToTreat(attackingTeam: attackingTeam)
            

            // healing execution
            // role means magus
            characterChoosen.role!.roleLife = characterChoosen.role!.roleLife + role.roleWeapon.weaponDamage
            print("\n     👺 Après les soins donnés par \(self.characterName), \(role.roleName), \(characterChoosen.characterName), \(characterChoosen.role!.roleName) a maintenant \(characterChoosen.role!.roleLife) points de vie 💪🏼")
            
            
            // move the concernedCharacter in the team from magus to the character traited
            characterChoosen.membership?.concernedCharacter = characterChoosen
            

        } // end of :  if !nobodyToTreat {
        
        // new choice available : true or false
        return newChoice

    } // end of: func healing()
    
    //Function that test if the healer is the last character alive of his team
    func checkIfMAgusIsTheLastCharacter(attackingTeam: Team, attackedTeam: Team) -> Bool {
        
        guard let role = self.role else {fatalError()}
        
        print ("\n     👺 C'est \(self.characterName) (\(role.roleName)) qui a été choisi !!!\n")
        
        // count of characters dead and/or with maxLife
        let (allTheFriendsOfTheTeamHaveDied, someFriendsOfTheTeamHaveADecreasedLife, allTheFriendsOfTheTeamHaveAMaxLife, allTheFriendsOfTheTeamAreDeadOrhaveMaxLife) = workforceInventory(team: attackedTeam)
        
//        if false {
//        displayOfBooleanInMagusAlone(allTheFriendsOfTheTeamHaveDied, allTheFriendsOfTheTeamHaveAMaxLife, allTheFriendsOfTheTeamAreDeadOrhaveMaxLife, someFriendsOfTheTeamHaveADecreasedLife)
//        }
        // in case of nob(ody to heal - new choice available
        var newChoice: Bool = false
        
        if allTheFriendsOfTheTeamHaveDied {
            
            theMagusWhoRemainedAloneFlees(team: attackedTeam, attackingTeam: attackingTeam, attackedTeam: attackedTeam)
            
            // no new choice asked
            newChoice = false
            
        } else {
            
            print("         \(self.characterName) (\(role.roleName)) ne sait pas se battre !\n\n         D'autres Champions peuvent se battre !\n\n         Equipe \(attackedTeam.teamName) choisissez un autre Champion !\n")

            // new choice asked
            newChoice = true
            
        } // end of : if allTheFriendsOfTheTeamHaveDied {
        
        // new choice available : true or false
        return newChoice
        
    } // end of: func healing()
    

    //Function for ask who to treat
    private func showPlayersToTreat(attackingTeam: Team) {
    
        for index in 0 ... const.DEFAULT_CHARACTERS_NUMBER - 1 {
            guard let attackingTeamPlayerRole = attackingTeam.teamCharacters[index].role else {fatalError()}
            
            print("- \(index+1) - \(attackingTeam.teamCharacters[index].characterName) \(attackingTeamPlayerRole.roleName) \(attackingTeamPlayerRole.roleLife)")
        }
        print("")
        print("Qui veux-tu soigner ?", terminator: "")
        print("")
    } // end of : func showPlayersToTreat
    
    
    //Function for choose a player to treat
    private func choiceOfAPlayerToTreat(attackingTeam: Team) -> Character {
        
        //variable of input verification
        var choiceOK: Bool = false
        
        var chosen: Int = 0
        
        repeat {
            
            if let choice = readLine() {
                if !choice.isEmpty {
                    if Int(choice)! >= 1, Int(choice)! <= const.DEFAULT_CHARACTERS_NUMBER {
                        chosen = Int(choice)! - 1
                        choiceOK = validCareChoice(player: attackingTeam.teamCharacters[chosen])
                        //if the choosen character is alive or not full life
                    } else {
                        choiceOK = false
                    }
                } // end of : if !choice.isEmpty {
            } // end of : if let choice = readLine()
        } while choiceOK == false

        return (attackingTeam.teamCharacters[chosen])
        
    } // end of : func choiceOfAPlayerToTreat
    
    //Function that prevent the healer from healing himself, heals a dead ally or heals a healthy ally
    private func validCareChoice (player: Character) -> Bool {
        guard let playerRole = player.role else {fatalError()}
        if playerRole.roleName == const.druidRole || playerRole.roleName == const.chamanRole || playerRole.roleName == const.priestRole {
            print(" Un guérisseur ne peut pas se soigner lui même, essayer autre chose")
            return false
        } else
            if playerRole.roleLife <= 0 {
                print(" Un guérisseur ne peut pas ressucité les morts , essayer autre chose")
                return false
        } else
            if playerRole.roleLife >= playerRole.maxLife {
                print(" Un guérisseur ne peut pas soigner un Champion en pleine santé, essayer autre chose")
                return false
        } else {
                return true
        }
    } // end of : func validCareChoice
    

    //Function to test if the last character is a healer in which case the fight end
    fileprivate func theMagusWhoRemainedAloneFlees(team: Team, attackingTeam: Team, attackedTeam: Team) {
        
            print ("     Ayant sont équipe \(team.teamName) décimé par l'ennemi le guérisseur resté seul ne sait pas se battre et ne peut plus rien faire...\n         Il abandonne la bataille, et son équipe est déclarer vaincu ! 👎🏻\n")
            
            // the currentFighter currently magus is considered as dead
            guard let role = self.role else {fatalError()}
            role.roleLife = 0 // magus is considered as dead because he is the only survivor and he can't fight, so we declare the end of the game
        
        // update property
        self.isCharacterStillAlive = false
        
        
    } // end of :  fileprivate func survisorAvailable(_ attackingTeam: Team, _ noSurvivor: inout Bool) {
    
    
    //function to determine who was wounded, killed or healed
    private func workforceInventory(team: Team) -> (allDead: Bool, someWithDecreasedFife: Bool, allWithMaxFife: Bool, onlyDeadOrMaxLife: Bool) {
        
        var characterDead : Int = 0
        var characterWithDecreasedLife : Int = 0
        var characterWithFullLife : Int = 0
        
        var allDead: Bool = false
        var someWithDecreasedFife: Bool = false
        var allWithFullFife: Bool = false
        var onlyDeadOrMaxLife: Bool = false
        
        team.teamCharacters.forEach { (character) in
            
            guard let role = character.role else {fatalError()}
            
            // nested tests because only one solution is possible
            if role.roleName != const.druidRole || role.roleName != const.chamanRole || role.roleName != const.priestRole {
                
                if role.roleLife == 0 {
                    characterDead += 1
                } else
                
                    if role.roleLife > 0 && role.roleLife < role.maxLife {
                        characterWithDecreasedLife += 1
                    } else
                
                        if role.roleLife == role.maxLife {
                            characterWithFullLife += 1
                } // end of : if role.roleLife == 0 {
                
            } // end of : nested tests because only one solution is possible
                
        } // end of : team.characters.forEach { (character) in

        // independent tests because several solutions are possible
        if characterDead == const.DEFAULT_CHARACTERS_NUMBER - 1 {
            allDead = true
        }
        
        if characterWithDecreasedLife > 0 {
            someWithDecreasedFife = true
        }
        
        if characterWithFullLife == const.DEFAULT_CHARACTERS_NUMBER - 1 {
            allWithFullFife = true
        }
        
        
        if characterDead + characterWithFullLife  == const.DEFAULT_CHARACTERS_NUMBER - 1 {
            onlyDeadOrMaxLife = true
        }
        
        //return bboolean values
        return (allDead, someWithDecreasedFife, allWithFullFife, onlyDeadOrMaxLife)
    } // end of :  private func someCharactersAvailableToTreat(attackingTeam: Team) -> Bool {


}// end of : extension Game
