//
//  role.swift
//  WarGame v2 Aurange
//
//  Created by Thomas Aurange on 26/10/2019.
//  Copyright © 2019 Thomas Aurange. All rights reserved.
//

import Foundation

//MARK: - Init of Role Class
class Role {
    var characterDependence: Character?
    var roleName: String
    var maxLife: Int
    var roleWeapon: Weapon
    
    var roleLife: Int {
        didSet {
            if roleLife <= 0 {
                self.characterDependence?.isCharacterStillAlive = false
            } else {
                self.characterDependence?.isCharacterStillAlive = true
            }//End of if roleLife <= 0
        }// End of didSet
    }// End of var roleLife: Int
    
    init(heritageOf: Character, roleName: String, maxLife: Int, roleLife: Int, roleWeapon: Weapon) {
        self.characterDependence = heritageOf
        self.roleName = roleName
        self.maxLife = maxLife
        self.roleWeapon = roleWeapon
        self.roleLife = roleLife
    }
    
}




class JuggernautRole: Role {
   var heritageOf: Character?
   init(heritageOf: Character) {
    super.init(heritageOf: heritageOf, roleName: const.juggenautRole, maxLife: const.juggenautMaxLife, roleLife: const.juggenautLife, roleWeapon: JuggernautWeapon())
    }
}
class CaptainRole: Role {
    var heritageOf: Character?
    init(heritageOf: Character) {
        super.init(heritageOf: heritageOf, roleName: const.captainRole, maxLife: const.captainMaxLife, roleLife: const.captainLife, roleWeapon: CaptainWeapon())
    }
}
class PaladinRole: Role {
    var heritageOf: Character?
    init(heritageOf: Character) {
        super.init(heritageOf: heritageOf, roleName: const.paladinRole, maxLife: const.paladinMaxLife, roleLife: const.paladinLife, roleWeapon: PaladinWeapon())
    }
}
class NinjaRole: Role {
    var heritageOf: Character?
    init(heritageOf: Character) {
        super.init(heritageOf: heritageOf, roleName: const.ninjaRole, maxLife: const.ninjaMaxLife, roleLife: const.ninjaLife, roleWeapon: NinjaWeapon())
    }
}
class HunterRole: Role {
    var heritageOf: Character?
    init(heritageOf: Character) {
        super.init(heritageOf: heritageOf, roleName: const.hunterRole, maxLife: const.hunterMaxLife, roleLife: const.hunterLife, roleWeapon: HunterWeapon())
    }
}
class SheriffRole: Role {
    var heritageOf: Character?
    init(heritageOf: Character) {
        super.init(heritageOf: heritageOf, roleName: const.sheriffRole, maxLife: const.sheriffMaxLife, roleLife: const.sheriffLife, roleWeapon: SheriffWeapon())
    }
}
class DruidRole: Role {
    var heritageOf: Character?
    init(heritageOf: Character) {
        super.init(heritageOf: heritageOf, roleName: const.druidRole, maxLife: const.druidMaxLife, roleLife: const.druidLife, roleWeapon: DruidWeapon())
    }
}
class ChamanRole: Role {
    var heritageOf: Character?
    init(heritageOf: Character) {
        super.init(heritageOf: heritageOf, roleName: const.chamanRole, maxLife: const.chamanMaxLife, roleLife: const.chamanLife, roleWeapon: ChamanWeapon())
    }
}
class PriestRole: Role {
    var heritageOf: Character?
    init(heritageOf: Character) {
        super.init(heritageOf: heritageOf, roleName: const.priestRole, maxLife: const.priestMaxLife, roleLife: const.priestLife, roleWeapon: PriestWeapon())
    }
}
