//
//  static_Functions.swift
//  WarGame v2 Aurange
//
//  Created by Thomas Aurange on 26/10/2019.
//  Copyright © 2019 Thomas Aurange. All rights reserved.
//

import Foundation

extension Game {
    
    // Array of ordinary numbers
    static var rank: [String] = ["Premier", "Second", "Troisème", "Quatrième", "Cinquième", "Sixième"]
    
    
    // Array of all characters names used in the game
    static var usedNames: [String] = [] //portée globale dans tout WarGame
    // Array of all roles names used in the game
    static var usedRoles: [String] = [] //portée globale dans tout WarGame
    
    
    // check if team name is duplicate
    static func checkIfDuplicatedName(name: String) -> Bool { //portée globale dans tout WarGame
        return self.usedNames.contains(name.uppercased())
    } // end of : func checkDuplicateName()
} // end of : extension Game{
