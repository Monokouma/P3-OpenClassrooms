//
//  extension_battle.swift
//  WarGame v2 Aurange
//
//  Created by Thomas Aurange on 26/10/2019.
//  Copyright © 2019 Thomas Aurange. All rights reserved.
//

import Foundation


extension Game {
    //MARK: - Main function of Fight, Dodge and first and swap
    
    
    func battle() {
        
        var counter: Int = 0
        
        var attackingCharacter: Character
        var attackedCharacter: Character
        
        var attackingTeam: Team?
        var attackedTeam: Team?
        
        var teamOne: Team = teams[0]
        var teamTwo: Team = teams[1]
        
        // true = normal fight => teamAttake = winner
        // false = dodge => attackedTeam = winner
        var fightOrDodge: Bool = false
        
        repeat {
            counter += 1
            print("\n\(const.LINE)")
            print("             Combat numéro \(counter)")
            print("\n\(const.LINE)")
            
            firstAndSwap(counter: counter, teams: teams, attackingTeam: &attackingTeam, attackedTeam: &attackedTeam, teamOne: teamOne, teamTwo: teamTwo)
            
            guard var currentattackingTeam = attackingTeam else {fatalError()}
            guard var attackedTeam = attackedTeam else {fatalError()}
            var newChoice: Bool
            
            repeat {
                
                newChoice = false
                
                attackingCharacter = currentattackingTeam.currentCharacterChoice()
                currentattackingTeam.concernedCharacter = attackingCharacter
                
                guard let currentCharacterAttackerRole = attackingTeam?.concernedCharacter?.role else {fatalError()}
                
                if currentCharacterAttackerRole.roleName == const.druidRole || currentCharacterAttackerRole.roleName == const.chamanRole || currentCharacterAttackerRole.roleName == const.priestRole {
                    
                    newChoice = attackingCharacter.healing(attackingTeam: currentattackingTeam, attackedTeam: attackedTeam)
                } // end of : if currentFighter.role!.roleName == constants.MAGUS_ROLE
            } while newChoice
            
            if attackingCharacter.role!.roleName != const.druidRole || attackingCharacter.role!.roleName != const.chamanRole || attackingCharacter.role!.roleName != const.priestRole {
                repeat {
                    
                    newChoice = false
                    
                    attackedCharacter =  attackedTeam.currentCharacterChoice()
                    attackedTeam.concernedCharacter = attackedCharacter
                    
                    guard let currentCharacterTargetRole = attackedTeam.concernedCharacter?.role else {fatalError()}
                    if currentCharacterTargetRole.roleName == const.druidRole || currentCharacterTargetRole.roleName == const.chamanRole || currentCharacterTargetRole.roleName == const.priestRole {
                        
                        newChoice = attackedCharacter.checkIfMAgusIsTheLastCharacter(attackingTeam: currentattackingTeam, attackedTeam: attackedTeam)
                        fightOrDodge = true
                    } // end of : if currentFighter.role!.roleName == constants.MAGUS_ROLE
                    
                } while newChoice
                
                if teams[0].CheckIfTeamIsAlive() && teams[1].CheckIfTeamIsAlive() {
                    
                    fightOrDodge = assault(counter: counter, attackingTeam: &currentattackingTeam, attackedTeam: &attackedTeam)
                } // end of :  if teams[0].CheckIfTeamIsAlive() && teams[1].CheckIfTeamIsAlive() {
            }//End of if currentCharacterAttacker.role!.roleName != const.CHARACTER7_ROLE
            
            (teamOne, teamTwo) = displayOfTheStateOfTheForcesAfterTheAssault(counter, fightOrDodge, attackingTeam: currentattackingTeam, attackedTeam: attackedTeam)
            
        } while teams[0].CheckIfTeamIsAlive() && teams[1].CheckIfTeamIsAlive()

    } // end of : func battle() {
    
    
    //function determining in a random way the first team that will attack
    fileprivate func firstAndSwap(counter: Int, teams: [Team], attackingTeam: inout Team?, attackedTeam: inout Team?, teamOne: Team, teamTwo: Team) {
        if counter == 1 {
            let randomValue = Bool.random()
            switch (randomValue) {
            case true:
                attackingTeam = teams[0]
                attackedTeam = teams[1]
            case false:
                attackingTeam = teams[1]
                attackedTeam = teams[0]
            }// End of switch (randomValue)
            for _ in 1...const.NUMBER_OF_REPEAT0 {print("⚡️", terminator: "")}
            print("")
            print("Une pièce est lancée 🟡 Elle retombe et désigne \(attackingTeam?.teamName ?? "erreur 1417") comme premier attaquant !" )
            for _ in 1...const.NUMBER_OF_REPEAT0 {print("⚡️", terminator: "")}
            print("")
        } else {
            attackingTeam = teamTwo
            attackedTeam = teamOne
            for _ in 1...const.NUMBER_OF_REPEAT0 {print("⚡️", terminator: "")}
            print("")
            print("⚡️⚡️⚡️ L'équipe \(attackingTeam?.teamName ?? "erreur 1442") ayant perdu l'assaut numéro \(counter-1) peut maintenant attaquer 🗡 !" )
        for _ in 1...const.NUMBER_OF_REPEAT0 {print("⚡️", terminator: "")}
        print("")
        } // end of : if counter == 1
    }//End of  fileprivate func firstAndSwap
    
    
    //Determining function according to the turn if there will be a dodge or if the fight will take place nomally
    private func assault(counter: Int, attackingTeam: inout Team, attackedTeam: inout Team) -> Bool {
        var fightRealized: Bool
        //If we are in turn 3, 5 or 7 and more
        if counter == 3 || counter == 5 || counter >= 7 && Bool.random() {
            dodge(attackingTeam: attackingTeam, attackedTeam: attackedTeam)
            fightRealized = false // type of fight : dodge
        } else {// end of : if Bool.random() {
            fight(attackingTeam: attackingTeam, attackedTeam: attackedTeam)
            fightRealized = true // type of fight : normal
        } // end of : if counter == 3 || counter == 5 counter => 7
        return fightRealized
    } // end of : func attack(counter: Int)
    
    
    //Main function for dodge
    fileprivate func dodge(attackingTeam: Team, attackedTeam: Team) {

        displayDodgeAnnouncement(attackingTeam: attackingTeam, attackedTeam: attackedTeam)
        
        if let attackedTeamConcernedCharacter = attackedTeam.concernedCharacter {
        attackedTeamConcernedCharacter.dodge(attackingTeam: attackingTeam, attackedTeam: attackedTeam)
        }
        
        dodgeExit(attackingTeam: attackingTeam, attackedTeam: attackedTeam)
    }//end of fileprivate func dodge(attackingTeam: Team, attackedTeam: Team) {
    
    //Main function for fight
    fileprivate func fight(attackingTeam: Team, attackedTeam: Team) {
        
        displayFightAnnouncement(attackingTeam: attackingTeam, attackedTeam: attackedTeam)
        
        if let attackedTeamConcernedCharacter = attackedTeam.concernedCharacter {
            attackedTeamConcernedCharacter.fight(attackingTeam: attackingTeam, attackedTeam: attackedTeam)
        }
        fightExit(attackingTeam: attackingTeam, attackedTeam: attackedTeam)
    }//End of fileprivate func fight
    

    //MARK: - Header for fight annoucement and dodge annoucement
    fileprivate func displayFightAnnouncementHeader(attackingTeam: Team, attackedTeam: Team) {
        guard let currentCharacterAttacker = attackingTeam.concernedCharacter else {fatalError()}
        guard let currentCharacterAttackerRole = attackingTeam.concernedCharacter?.role else {fatalError()}
        guard let currentCharacterTarget = attackedTeam.concernedCharacter else {fatalError()}
        guard let currentCharacterTargetRole = attackedTeam.concernedCharacter?.role else {fatalError()}
        
        print("💥 L'atmosphère se tend un combat va bientôt avoir lieu 💥")
        
        print("      Il opposera :\n        - l'attaquant \(currentCharacterAttacker.characterName), un \(currentCharacterAttackerRole.roleName) se battant pour l'honneur de l'équipe \(attackingTeam.teamName), avec \(currentCharacterAttackerRole.roleLife) points de vie,")
        
        print("        - contre \(currentCharacterTarget.characterName), un \(currentCharacterTargetRole.roleName) de l'équipe \(attackedTeam.teamName), avec \(currentCharacterTarget.role!.roleLife) points de vie." )
        
        print("")
        print("      ⚔️⚔️⚔️")
        print("      Le combat fait rage !")
        print("      ⚔️⚔️⚔️\n")
        
    }//End of fileprivate func displayFightAnnouncementHeader
    
    
   
    
    private func displayFightAnnouncement(attackingTeam: Team, attackedTeam: Team) {
        displayFightAnnouncementHeader(attackingTeam: attackingTeam, attackedTeam: attackedTeam)
        
    } // end of : private func printFightAnnouncement
    
    fileprivate func displayDodgeAnnouncementHeader(attackingTeam: Team, attackedTeam: Team) {
        
        guard let currentCharacterAttackerName = attackingTeam.concernedCharacter?.characterName else {fatalError()}
        
        guard let currentCharacterAttackerRoleName = attackingTeam.concernedCharacter?.role?.roleName else {fatalError()}
        guard let currentCharacterTargetName = attackedTeam.concernedCharacter?.characterName else {fatalError()}

        guard let currentCharacterTargetRoleName = attackedTeam.concernedCharacter?.role?.roleName else {fatalError()}

        for _ in 1...const.NUMBER_OF_REPEAT0 {print("⚡️", terminator: "")}
        print("")
        print(" \(currentCharacterTargetName), \(currentCharacterTargetRoleName) de l'équipe \(attackedTeam.teamName) vient d'esquiver et en profite pour contre-attaquer \(currentCharacterAttackerName), \(currentCharacterAttackerRoleName) de l'équipe \(attackingTeam.teamName)!")
        for _ in 1...const.NUMBER_OF_REPEAT0 {print("⚡️", terminator: "")}
        print("")
    }//End of fileprivate func displayDodgeAnnouncementHeader
    
    private func displayDodgeAnnouncement(attackingTeam: Team, attackedTeam: Team) {
       
        displayDodgeAnnouncementHeader(attackingTeam: attackingTeam, attackedTeam: attackedTeam)
        
    } // end of : private func printFightAnnouncement
    
    
    //MARK: - Fight exit and dodge exit functions
    
    
    private func fightExit(attackingTeam: Team, attackedTeam: Team) {
        
        guard let currentCharacterAttacker = attackingTeam.concernedCharacter else {fatalError()}
        guard let currentCharacterAttackerRole = attackingTeam.concernedCharacter?.role else {fatalError()}
        guard let currentCharacterTarget = attackedTeam.concernedCharacter else {fatalError()}
        guard let currentCharacterTargetRole = attackedTeam.concernedCharacter?.role else {fatalError()}
        
        if currentCharacterAttacker.isCharacterStillAlive {
            print("\n \(currentCharacterAttacker.characterName), un \(currentCharacterAttackerRole.roleName) se battant pour l'équipe \(attackingTeam.teamName), a blesser \(currentCharacterTarget.characterName). \n   Il lui retire \(currentCharacterAttackerRole.roleWeapon.weaponDamage) points de vie. ")
        } else {
            print("\n \(currentCharacterAttacker.characterName), un \(currentCharacterAttackerRole.roleName) se battant pour l'équipe \(attackingTeam.teamName), a blesser \(currentCharacterTarget.characterName).  \n  Le coup fut fatal et  \(currentCharacterTarget.characterName), un \(currentCharacterTargetRole.roleName) de l'équipe \(attackedTeam.teamName), est éliminé ⚰️\n")
        }//end of if currentCharacterAttacker.isCharacterStillAlive
    } // end of : func fightExit
    

    
    private func dodgeExit(attackingTeam: Team, attackedTeam: Team) {
        
        guard let currentCharacterAttacker = attackingTeam.concernedCharacter else {fatalError()}
        guard let currentCharacterAttackerRole = attackingTeam.concernedCharacter?.role else {fatalError()}
        guard let currentCharacterTarget = attackedTeam.concernedCharacter else {fatalError()}
        guard let currentCharacterTargetRole = attackedTeam.concernedCharacter?.role else {fatalError()}
        
        if currentCharacterAttacker.isCharacterStillAlive {
            print("\n \(currentCharacterAttacker.characterName), un \(currentCharacterAttackerRole.roleName) se battant pour l'équipe \(attackingTeam.teamName), a blesser \(currentCharacterTarget.characterName). \n   Il lui retire \(currentCharacterAttackerRole.roleWeapon.weaponDamage) points de vie. ")
        } else {
            print("\n \(currentCharacterAttacker.characterName), un \(currentCharacterAttackerRole.roleName) se battant pour l'équipe \(attackingTeam.teamName), a blesser \(currentCharacterTarget.characterName).  \n  Le coup fut fatal et  \(currentCharacterTarget.characterName), un \(currentCharacterTargetRole.roleName) de l'équipe \(attackedTeam.teamName), est éliminé ⚰️\n")
        } // end of :if currentFighter.isCharacterAlive {
    } // end of : func fightExit

    
    
    //Function to display who has won the fight of the turn concerned and update the life point, also displays a summary of the combat at determined turns
    fileprivate func displayOfTheStateOfTheForcesAfterTheAssault(_ counter: Int, _ fightOrDodge: Bool, attackingTeam: Team, attackedTeam: Team) -> (teamOne: Team, teamTwo: Team) {
        
        var teamOne: Team = attackingTeam
        var teamTwo: Team = attackedTeam
        
        switch fightOrDodge {
            case true : // means : fight : attackingTeam winner
                teamOne = attackingTeam
                teamTwo = attackedTeam
            case false : // means : dodge : attackedTeam winner
                teamOne = attackedTeam
                teamTwo = attackingTeam
        }//End of switch fightOrDodge
            
        print("\n      Le combat numéro : \(counter) est fini, ceux qui peuvent rentrer à la base rentrent. \n L'équipe \(teamOne.teamName) remporte l'assaut 💪🏼")
        //Summary will be displayed at turn 3, 5, 7 etc etc
        if counter == 3 || counter == 5 || counter == 7 || counter == 9 || counter == 11 || counter == 13 {
        teamOne.teamCharactersStatusDisplay()
        teamTwo.teamCharactersStatusDisplay()
        }
        print("")
        return (teamOne, teamTwo)
    }//End of fileprivate func displayOfTheStateOfTheForcesAfterTheAssault
}// end of : extension Game
