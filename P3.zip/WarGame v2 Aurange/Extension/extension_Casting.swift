//
//  extension_Casting.swift
//  WarGame v2 Aurange
//
//  Created by Thomas Aurange on 26/10/2019.
//  Copyright © 2019 Thomas Aurange. All rights reserved.
//

import Foundation

extension Game {
    
    
    
    // MARK: - Casting of the players names
    func casting() {
        setPlayersNames()
        
        for indexPlayer in 0...const.DEFAULT_PLAYERS_NUMBER - 1 {
           teams.append(Team(playerName: playersNames[indexPlayer]))
           teams[indexPlayer].teamCharactersStatusDisplay()
        } // end of : for indexPlayer
    } // end of : func casting() {
  
    // MARK: - Setting up Players Names
    private func setPlayersNames() {
        var isnameDuplicated: Bool = false
        
        for indexPlayer in 0...const.DEFAULT_PLAYERS_NUMBER - 1 {
            repeat {
                print("\n \(Game.rank[indexPlayer]) joueur : Quel est votre nom ? : ", terminator: "")
                if let inputData = readLine() {
                    if !inputData.isEmpty {
                        isnameDuplicated = Game.checkIfDuplicatedName(name: inputData)
                        if isnameDuplicated {
                            print("\n   \(const.NAME_ALREADY_CHOOSEN)")
                        } else {
                            self.playersNames.append(inputData)
                            Game.usedNames.append(inputData.uppercased())
                        } // end of : if isnameDuplicated {
                    } else { // if inputData.isEmpty {
                        print("\n   Erreur ! Réessayer !\n")
                        isnameDuplicated = true
                    } // end of : if !inputData.isEmpty {
                } //end of : if let teamName = readLine()
            } while isnameDuplicated == true
        } // end of : for player in 0...1 {
    } //end of : func setTeamName()
    
}// end of : extension Game
