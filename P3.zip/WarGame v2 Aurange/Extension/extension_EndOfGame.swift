//
//  extension_EndOfGame.swift
//  WarGame v2 Aurange
//
//  Created by Thomas Aurange on 26/10/2019.
//  Copyright © 2019 Thomas Aurange. All rights reserved.
//

import Foundation

extension Game {
    
    // finally, stop the game or restart it
    func endOfGame() {
        
        podium()
        
        displayTeamInventoryTittle()
        
        teamInventory()
        
    } // end of : func endOfGame()
    
    
    
    private func podium() {
        
        var winner: Int
        var looser: Int
        
        //Display of game result
        

        print("     Fin du combat 👎🏻\n")
        
        usleep(useconds_t(const.PAUSE_DISPLAY)) //will sleep for 1/4 second
        
        print("     Une équipe semble anéantie ! Voyons voir ça :\n")
        
        usleep(useconds_t(const.PAUSE_DISPLAY)) //will sleep for 1/4 second
        
        // Who is the winner?
        // if one team is dead, the other is the winner
        if teams[0].CheckIfTeamIsAlive() {
            winner = 0
            looser = 1
        } else {
            winner = 1
            looser = 0
        }
        
        for _ in 1...const.NUMBER_OF_REPEAT0 {print("🔱", terminator: "")}
        print("")
        
        print("🔱")
                        for _ in 1...const.NUMBER_OF_REPEAT1 {print(" ", terminator: "")}
                        print("🔱")
        
        print("🔱  ☘️ L'équipe \(teams[winner].teamName) de \(playersNames[winner]) est vainqueur! ☘️")
        
        print("🔱")
                        for _ in 1...const.NUMBER_OF_REPEAT1 {print(" ", terminator: "")}
                        print("🔱")
        
        print("🔱     L'équipe \(teams[looser].teamName) de \(playersNames[looser]) est perdante 👎🏻")
        
        print("🔱")
                        for _ in 1...const.NUMBER_OF_REPEAT1 {print(" ", terminator: "")}
                        print("🔱")
        
        for _ in 1...const.NUMBER_OF_REPEAT0 {print("🔱", terminator: "")}
        //            print("")
        //
        print("\n")
        
        usleep(useconds_t(const.PAUSE_DISPLAY)) //will sleep for 1/4 second
        
    } // end of : func printPodium()
    
    private func displayTeamInventoryTittle() {
        // summary
        
        usleep(useconds_t(const.PAUSE_DISPLAY)) //will sleep for 1/4 second
        
        print("🔥 Inventaire du statut des 2 équipes : 🔥")
        
    } // end of : func printTeamInventory()
    
    // team inventory at the end of the fight
    private func teamInventory() {
        var winner: Int
        var looser: Int
        // Who is the winner?
        // if one team is dead, the other is the winner
        if teams[0].CheckIfTeamIsAlive() {
            winner = 0
            looser = 1
        } else {
            winner = 1
            looser = 0
        }
        usleep(useconds_t(const.PAUSE_DISPLAY)) //will sleep for 1/4 second
        // Display of the full Team 1
        teams[winner].teamCharactersStatusDisplay()
        
        usleep(useconds_t(const.PAUSE_DISPLAY)) //will sleep for 1/4 second
        // Display of the full Team 1
        teams[looser].teamCharactersStatusDisplay()
    } // end of : func teamInventory()
    

    
}// end of : extension Game
