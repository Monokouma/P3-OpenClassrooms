//
//  main.swift
//  WarGame v2 Aurange
//
//  Created by Thomas Aurange on 26/10/2019.
//  Copyright © 2019 Thomas Aurange. All rights reserved.
//

import Foundation


//instentiation
var game = Game()

// MARK: - Run the main function in the game instantiation

game.mainGame()
