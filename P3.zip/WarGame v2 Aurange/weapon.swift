//
//  weapons.swift
//  WarGame v2 Aurange
//
//  Created by Thomas Aurange on 26/10/2019.
//  Copyright © 2019 Thomas Aurange. All rights reserved.
//

import Foundation

// MARK: - Init of Materiel Class
class Weapon {
    var weaponName: String
    var weaponDamage: Int
    
    init(weaponName: String, weaponDamage: Int) {
        self.weaponName = weaponName
        self.weaponDamage = weaponDamage
    }
}

class JuggernautWeapon: Weapon {
    init() {
        super.init(weaponName: const.juggenautWeapon, weaponDamage: const.juggenautDamage)
    }
}
class CaptainWeapon: Weapon {
    init() {
        super.init(weaponName: const.captainWeapon, weaponDamage: const.captainDamage)
    }
}
class PaladinWeapon: Weapon {
    init() {
        super.init(weaponName: const.paladinWeapon, weaponDamage: const.priestDamage)
    }
}
class NinjaWeapon: Weapon {
    init() {
        super.init(weaponName: const.ninjaWeapon, weaponDamage: const.ninjaDamage)
    }
}
class HunterWeapon: Weapon {
    init() {
        super.init(weaponName: const.hunterWeapon, weaponDamage: const.hunterDamage)
    }
}
class SheriffWeapon: Weapon {
    init() {
        super.init(weaponName: const.sheriffWeapon, weaponDamage: const.sheriffDamage)
    }
}
class DruidWeapon: Weapon {
    init() {
        super.init(weaponName: const.druidWeapon, weaponDamage: const.druidDamage)
    }
}
class ChamanWeapon: Weapon {
    init() {
        super.init(weaponName: const.chamanWeapon, weaponDamage: const.chamanDamage)
    }
}
class PriestWeapon: Weapon {
    init() {
        super.init(weaponName: const.priestWeapon, weaponDamage: const.priestDamage)
    }
}
