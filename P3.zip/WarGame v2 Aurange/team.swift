//
//  team.swift
//  WarGame v2 Aurange
//
//  Created by Thomas Aurange on 26/10/2019.
//  Copyright © 2019 Thomas Aurange. All rights reserved.
//

import Foundation

// MARK: - Init of Team class
class Team {
    var playerName: String
    var teamName: String = ""
    var teamCharacters: [Character] = []
    var concernedCharacter: Character?
    var memRoles: [Int] = []
    
    init(playerName: String) {
        self.playerName = playerName
        setTeamName()
        setUpTeams()
    }
    
    
    //  MARK: - Setting up the team name
    func setTeamName() {
        var isnameDuplicated: Bool = false
        repeat {
                print("\n\(const.SUB_LINE)")
                print("\n   \(playerName) : Quel est le nom de votre équipe ? ", terminator: "")

            if let inputData = readLine() {
                if !inputData.isEmpty {
                    isnameDuplicated = Game.checkIfDuplicatedName(name: inputData)
                    if isnameDuplicated {
                        print("\n   \(const.NAME_ALREADY_CHOOSEN)")
                    } else {
                        self.teamName = inputData
                        Game.usedNames.append(inputData.uppercased())
                    }
                } else {
                    print("\n   Saisie invalide!\n")
                    isnameDuplicated = true
                } // end of : if !inputData.isEmpty {
            } //end of : if let teamName = readLine()
        } while isnameDuplicated == true
    }//End of setTeamName
    
    
    
    
    
    
    // MARK: - Setting up of Teams
    func setUpTeams() {
        
        print("\n   Équipe \(self.teamName) : Choisissez qui combattra pour votre honneur !\n")
        
        for indexCharacter in 0...const.DEFAULT_CHARACTERS_NUMBER - 1 {
            
            print("      Choix du \(Game.rank[indexCharacter]) Champion :\n")
            
            self.teamCharacters.append(Character(membership: self))
            self.teamCharacters[indexCharacter].showInfoAboutCharacter()
        } // end of : for ijk in 0...constants.DEFAULT_CHARACTERS_NUMBER - 1 {
    } // end of : func setUpTeams() {
    
    
    
    // Function allowing the choice of the character
    func currentCharacterChoice() -> Character {
        let currentCharacter: Character?
        self.displayTeamCharacters()
        currentCharacter = self.characterChoice()
        guard let returnedCurrentCharacter = currentCharacter else {fatalError()}
        return returnedCurrentCharacter
    } // end of : func currentCharacterChoice
    
    
    // Function to display the character of the Team with its characteristics
    private func displayTeamCharacters() {
        print("\n    Équipe \(self.teamName) : Choisissez qui combattra pour votre honneur !\n")
        for index in 0 ... const.DEFAULT_CHARACTERS_NUMBER - 1 {
            guard let teamPlayerRole = self.teamCharacters[index].role else {fatalError()}
            print("       \(index+1) - \(self.teamCharacters[index].characterName) \(teamPlayerRole.roleName) \(teamPlayerRole.roleLife) points de vie")
        } //end of : for index in 0 ...
    } // end of : private func displayTeamPlayers

    
    //Function to choose a character among 3 classes of 3 characters each
    func characterChoice() -> Character{
        var characterChoosen: Character = self.teamCharacters[0] // arbitrary initialization to handle the optional
        var choiceOK: Bool = false
        repeat {
            if let choice = readLine() {
                if choice == "1" || choice == "2" || choice == "3" || choice == "4" || choice == "5" || choice == "6" || choice == "7" || choice == "8" || choice == "9" {
                    let index = Int(choice)! - 1
                    characterChoosen = self.teamCharacters[index]
                    choiceOK = checkIfCharacterChoosenIsAlwaysAlive(choosenCharacter: characterChoosen)
                } else {
                    choiceOK = false
                    print("      erreur de saisie, recommencez !\n")
                }// end of : if let choice = readLine()
            } // end of : if let choice = readLine() {
        } while choiceOK == false
        return characterChoosen
    } // end of : func fighterChoice
    
    
    // Function to test if the choosen character is always alive
    private func checkIfCharacterChoosenIsAlwaysAlive(choosenCharacter: Character) -> Bool {
        if choosenCharacter.isCharacterStillAlive {
            return true
        } else {
            print ("\(choosenCharacter.characterName) est mort ⚰️, choisis un autre Champion !")
            return false
        }
    } // end of : func isAliveCheck
    
    
    // Function to display the characteristics of the character according to their teams
    func teamCharactersStatusDisplay() {
        

        print("\n      Joueur : \(self.playerName) - Equipe : \(self.teamName) :")
        for index in 0...const.DEFAULT_CHARACTERS_NUMBER - 1 {
            guard let characterRole = self.teamCharacters[index].role else {fatalError()}


            print("      Champion \(index + 1) : \(self.teamCharacters[index].characterName) - Rôle : \(characterRole.roleName) - Points de vie : \(characterRole.roleLife) / \(characterRole.maxLife) - Équipement : \(characterRole.roleWeapon.weaponName) - Dégats : \(characterRole.roleWeapon.weaponDamage)")
        } // end of : for index in 0...constants.DEFAULT_CHARACTERS_NUMBER - 1 {
    }//End of func teamCharactersStatusDisplay()
    
    
    // Function to test if the team is alive or not
    func CheckIfTeamIsAlive() -> Bool {
        var totalLife: Int = 0
        self.teamCharacters.forEach { (character) in
            guard let role = character.role else {fatalError()}
            totalLife += role.roleLife
        }

        return totalLife > 0 ? true : false
    } // end of : func isTeamAlive() -> Bool

}//End of class Team
