//
//  game.swift
//  WarGame v2 Aurange
//
//  Created by Thomas Aurange on 26/10/2019.
//  Copyright © 2019 Thomas Aurange. All rights reserved.
//

import Foundation

class Game {
    
    var playersNames: [String] = [] //active throughout the game
    var teams: [Team] = [] //active throughout the game
    var team: Team? //active throughout the game
    
    func mainGame() {
        //Diplay the title of the game
        print("\(const.LINE)")
        print("      \(const.symbol2) \n")
        print("\(const.GAME_TITLE)") //display the game title
        print("      \(const.symbol) \n")
        print("\(const.LINE)")
        
        //Main functions of the game
        casting() // extension_Casting
        battle() // extension_battle
        endOfGame() // extension_EndOfGame
    }//End of function mainGame()
    
    
    
    
}//End of class Game

