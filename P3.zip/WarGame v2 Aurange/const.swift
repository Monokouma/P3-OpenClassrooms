//
//  const.swift
//  WarGame v2 Aurange
//
//  Created by Thomas Aurange on 26/10/2019.
//  Copyright © 2019 Thomas Aurange. All rights reserved.
//

import Foundation

struct const {


static let GAME_TITLE = "WarGame Of The Night\n"

static let LINE = "⎼⎼⎼⎼⎼⎼⎼⎼⎼⎼⎼⎼⎼⎼⎼⎼⎼⎼⎼⎼⎼\n"

static let symbol = "⚔️🔮🛡"
    
static let symbol2 = "🛡🔮⚔️"
    
static let SUB_LINE = "   =================================================\n"

static let SUB_SUB_LINE = "      =================================================\n"

static let NUMBER_OF_REPEAT0 = 45

static let NUMBER_OF_REPEAT1 = 73

static let NAME_ALREADY_CHOOSEN = "   ❌ Attention ❌ Ce nom est déjà pris, essayez à nouveau !\n"

static let TEAM_ROLE_ALREADY_CHOOSEN = "     ❌ Attention ❌ Ce role est déjà utilisé dans l'équipe, choisissez-en un autre !\n"

//Default Players number
static let DEFAULT_PLAYERS_NUMBER = 2 // limited to 2
//Default Characters number
static let DEFAULT_CHARACTERS_NUMBER = 3 // limited to 3

//Default Characters number
static let DEFAULT_CHARACTERS_ROLES = 9 // limited to 9


static let PAUSE_DISPLAY = 250000 //will sleep for 1/4 second

//MARK: - Champ Constants
    
    
    
    
    //MARK: -TANK CONST
//Juggenaut constants
static let juggenautMaxLife = 200
static let juggenautLife = 200
static let juggenautRole = "Mastodonte"
static let juggenautWeapon = "Bouclier Anti-Émeute 🛡"
static let juggenautDamage = 50
//Captain constants
static let captainMaxLife = 200
static let captainLife = 200
static let captainRole = "Capitaine"
static let captainWeapon = "Hâche de Combat 🪓"
static let captainDamage = 50
//Paladin constants
static let paladinMaxLife = 200
static let paladinLife = 200
static let paladinRole = "Paladin"
static let paladinWeapon = "Épée Sacré 🗡"
static let paladinDamage = 50

    
   //MARK: -DPS const
    
//Ninja constants
static let ninjaMaxLife = 100
static let ninjaLife = 100
static let ninjaRole = "Ninja"
static let ninjaWeapon = "Kumâken 🔪"
static let ninjaDamage = 100
//Hunter constants
static let hunterMaxLife = 100
static let hunterLife = 100
static let hunterRole = "Chasseur"
static let hunterWeapon = "Arc Long 💎"
static let hunterDamage = 100
//Sheriff constants
static let sheriffMaxLife = 100
static let sheriffLife = 100
static let sheriffRole = "Sheriff"
static let sheriffWeapon = "Revolver 🔫"
static let sheriffDamage = 100

    //MARK: -HEALER const
//Druid constants
static let druidMaxLife = 100
static let druidLife = 100
static let druidRole = "Druide"
static let druidWeapon = "Bâton de Druide 🧹"
static let druidDamage = 50
//Chaman constants
static let chamanMaxLife = 100
static let chamanLife = 100
static let chamanRole = "Chaman"
static let chamanWeapon = "Totem de Vie 📿"
static let chamanDamage = 50
//Priest constants
static let priestMaxLife = 100
static let priestLife = 100
static let priestRole = "Prêtre"
static let priestWeapon = "Prières 🙏🏼"
static let priestDamage = 50
}//End of struc const
